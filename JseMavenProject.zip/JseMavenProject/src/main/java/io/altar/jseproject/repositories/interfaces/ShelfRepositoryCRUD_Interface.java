package io.altar.jseproject.repositories.interfaces;

import io.altar.jseproject.model.Shelf;

public interface ShelfRepositoryCRUD_Interface  extends EntityRepositoryCRUD_Interface<Shelf>{

}